# Reference data staging

Large production references are intentionally not bundled. Stage them on the target machine and update `reference_manifest.yaml`.

For migration self-test only, this bundle includes tiny files under `refs/test_refs/` and a matching manifest:

```text
refs/reference_manifest.test_refs.yaml
```

These tiny files are not biologically valid production references. They exist only to prove that Doctor path/layout checks can pass on a freshly unpacked bundle.

Production Doctor previously blocked on these template paths:

```text
/ref/GRCh38.fa
/ref/gencode.v44.annotation.gtf
/ref/vep_cache/homo_sapiens/115_GRCh38
```

Recommended production target layout:

```text
/path/to/neoag_refs/
  GRCh38.fa
  GRCh38.fa.fai
  GRCh38.dict
  gencode.v44.annotation.gtf
  vep_cache/homo_sapiens/115_GRCh38/
  facets/common_snp.vcf.gz
  facets/common_snp.vcf.gz.tbi
```

After staging real references, edit `reference_manifest.yaml` so every path points to the target machine location, then rerun Doctor.
