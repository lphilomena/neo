# Environment migration notes

Validated source installation root:

```text
/mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools
```

Fresh migration notes:

1. Install Miniforge/conda on the new machine.
2. Use Python 3.11 for `neoag-core`.
3. Install OpenJDK 17 in `neoag-core`.
4. Create `neoag-tools` from `env.neoag-tools-lite.bioconda.yml`.
5. Update `activate_neoag_env.example.sh` paths for the new machine.
6. Run the repo skill bootstrap and Doctor again.

Important migration finding:

The original project file `conda/env.neoag-tools-lite.yml` declares only `conda-forge`, but `bcftools` resolves from `bioconda`. The bundled `env.neoag-tools-lite.bioconda.yml` adds `bioconda` and was validated by fresh install.

Validated commands on source server:

```text
python 3.11.15
java 17.0.18
samtools 1.23.1
bcftools 1.24
mhcflurry-predict --help
pvacseq --help
neoag-v03 run-demo
```
