#!/usr/bin/env bash
# Local activation for neo-na0707_upload_release-3 on 10.200.50.134.
export NEOAG_PROJECT_ROOT="/mnt/zjl-bgi-zzb/peixunban/gl/liup/neo-na0707_upload_release-3"
export NEOAG_TOOLS_ROOT="/mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools"
export NEOAG_CONDA_BASE="$NEOAG_TOOLS_ROOT/miniforge3"
export NXF_HOME="$NEOAG_TOOLS_ROOT/nextflow"
export PYTHONPATH="$NEOAG_PROJECT_ROOT/src${PYTHONPATH:+:$PYTHONPATH}"
export PATH="$NEOAG_PROJECT_ROOT/bin:$NEOAG_CONDA_BASE/envs/neoag-core/bin:$NEOAG_CONDA_BASE/envs/neoag-tools/bin:$NEOAG_CONDA_BASE/bin:$PATH"
export LD_LIBRARY_PATH="$NEOAG_CONDA_BASE/envs/neoag-tools/lib:$NEOAG_CONDA_BASE/envs/neoag-core/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
