# Recommended fixes

## arriba [MISSING]

- Message: not found on PATH
- Path: arriba
- Suggested fix: Install the tool or set its executable path in tools_manifest.

## deepimmuno [MISSING]

- Message: not found on PATH
- Path: deepimmuno-cnn.py
- Suggested fix: Install the tool or set its executable path in tools_manifest.

## easyfuse [MISSING]

- Message: not found on PATH
- Path: easyfuse
- Suggested fix: Install the tool or set its executable path in tools_manifest.

## fusioncatcher [MISSING]

- Message: not found on PATH
- Path: fusioncatcher
- Suggested fix: Install the tool or set its executable path in tools_manifest.

## hla_la [MISSING]

- Message: not found on PATH
- Path: HLA-LA.pl
- Suggested fix: Install the tool or set its executable path in tools_manifest.

## lohhla [MISSING]

- Message: not found on PATH
- Path: LOHHLA
- Suggested fix: Install the tool or set its executable path in tools_manifest.

## netmhcpan [LICENSE_REQUIRED]

- Message: licensed tool; install locally and record path in tools_manifest
- Path: netMHCpan
- Suggested fix: Install/configure this licensed tool locally; do not redistribute binaries or licensed data.

## netmhcstabpan [LICENSE_REQUIRED]

- Message: licensed tool; install locally and record path in tools_manifest
- Path: NetMHCstabpan
- Suggested fix: Install/configure this licensed tool locally; do not redistribute binaries or licensed data.

## novoalign [MISSING]

- Message: not found on PATH
- Path: novoalign
- Suggested fix: Install the tool or set its executable path in tools_manifest.

## optitype [MISSING]

- Message: not found on PATH
- Path: OptiTypePipeline.py
- Suggested fix: Install the tool or set its executable path in tools_manifest.

## polysolver [MISSING]

- Message: not found on PATH
- Path: shell_call_hla_type
- Suggested fix: Install the tool or set its executable path in tools_manifest.

## prime [MISSING]

- Message: not found on PATH
- Path: PRIME
- Suggested fix: Install the tool or set its executable path in tools_manifest.

## sequenza [MISSING]

- Message: not found on PATH
- Path: sequenza-utils
- Suggested fix: Install the tool or set its executable path in tools_manifest.

## spechla [MISSING]

- Message: not found on PATH
- Path: SpecHLA
- Suggested fix: Install the tool or set its executable path in tools_manifest.

## star [MISSING]

- Message: not found on PATH
- Path: STAR
- Suggested fix: Install the tool or set its executable path in tools_manifest.

## star_fusion [MISSING]

- Message: not found on PATH
- Path: STAR-Fusion
- Suggested fix: Install the tool or set its executable path in tools_manifest.

## netmhcpan.license [LICENSE_REQUIRED]

- Message: licensed/restricted tool; verify local license and do not redistribute binaries
- Path: local_license
- Suggested fix: Install/configure this licensed tool locally; do not redistribute binaries or licensed data.

## normal_proteome [MISSING]

- Message: path does not exist
- Path: /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/refs/MISSING_normal_proteome.fa
- Suggested fix: Download or symlink the required reference file/cache and update reference_manifest.

## normal_ligandome [MISSING]

- Message: path does not exist
- Path: /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/refs/MISSING_normal_ligandome.tsv
- Suggested fix: Download or symlink the required reference file/cache and update reference_manifest.

## facets_snp_vcf [MISSING]

- Message: path does not exist
- Path: /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/refs/facets/MISSING_common_snp.vcf.gz
- Suggested fix: Download or symlink the required reference file/cache and update reference_manifest.

## tumor.wgs_bam [MISSING]

- Message: path does not exist
- Path: data/fixtures/tumor.wgs.bam
- Suggested fix: Review the manifest entry and installation path.

## tumor.wts_bam [MISSING]

- Message: path does not exist
- Path: data/fixtures/tumor.rna.bam
- Suggested fix: Review the manifest entry and installation path.

## normal.wgs_bam [MISSING]

- Message: path does not exist
- Path: data/fixtures/normal.wgs.bam
- Suggested fix: Review the manifest entry and installation path.

## inputs.somatic_vcf [MISSING]

- Message: path does not exist
- Path: data/fixtures/somatic.pass.vcf.gz
- Suggested fix: Review the manifest entry and installation path.

## inputs.sv_vcf._list[0] [MISSING]

- Message: path does not exist
- Path: data/fixtures/manta.somaticSV.vcf.gz
- Suggested fix: Review the manifest entry and installation path.

## inputs.fusion_tsv [MISSING]

- Message: path does not exist
- Path: results/SAMPLE001/fusion/fusions.pass.csv
- Suggested fix: Review the manifest entry and installation path.

## inputs.expression_tsv [MISSING]

- Message: path does not exist
- Path: results/SAMPLE001/rna/gene_tpm.tsv
- Suggested fix: Review the manifest entry and installation path.

## inputs.purity_tsv [MISSING]

- Message: path does not exist
- Path: results/SAMPLE001/cnv/facets_purity.tsv
- Suggested fix: Review the manifest entry and installation path.

## facets_snp_vcf.tbi [MISSING]

- Message: main reference file is missing
- Path: /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/refs/facets/MISSING_common_snp.vcf.gz
- Suggested fix: Download or symlink the required reference file/cache and update reference_manifest.

## lohhla_reference [MISSING]

- Message: declared path missing
- Path: /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/refs/lohhla/MISSING_hla_reference
- Suggested fix: Download or symlink the required reference file/cache and update reference_manifest.

## ascat_loci [MISSING]

- Message: declared path missing
- Path: /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/refs/ascat/MISSING_G1000_loci_hg38.txt
- Suggested fix: Download or symlink the required reference file/cache and update reference_manifest.

## ascat_alleles [MISSING]

- Message: declared path missing
- Path: /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/refs/ascat/MISSING_G1000_alleles_hg38.txt
- Suggested fix: Download or symlink the required reference file/cache and update reference_manifest.

## arriba_reference [MISSING]

- Message: declared path missing
- Path: /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/refs/MISSING_arriba_reference
- Suggested fix: Download or symlink the required reference file/cache and update reference_manifest.

## hla_reference [MISSING]

- Message: declared path missing
- Path: /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/refs/MISSING_hla_reference
- Suggested fix: Download or symlink the required reference file/cache and update reference_manifest.

