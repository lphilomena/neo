# Deployment report

Project root: `/mnt/zjl-bgi-zzb/peixunban/gl/liup/neo-na0707_upload_release-3`
Deployment workdir: `/mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/work/remote_deploy_final`
Doctor status: `UNSAFE`

## Outputs

- `/mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/work/remote_deploy_final/smoke_test_report.md`
- `/mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/work/remote_deploy_final/doctor/doctor_summary.md`
- `/mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/work/remote_deploy_final/doctor/blocking_issues.tsv`
- `/mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/work/remote_deploy_final/doctor/recommended_fixes.md`

## Safety boundary

This deployment report does not certify clinical use. Missing tools or references are deployment gaps, not biological negative evidence.
