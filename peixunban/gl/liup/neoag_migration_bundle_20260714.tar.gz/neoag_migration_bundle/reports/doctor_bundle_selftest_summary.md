# NeoAg Doctor

Status: **PARTIAL**
Checked at: 2026-07-14T10:08:21+0800

## Summary
| OK | INFO | DRY_RUN | MISSING | LICENSE_REQUIRED |
| --- | --- | --- | --- | --- |
| 40 | 16 | 2 | 27 | 3 |

## Blocking issues

（无记录）


## Tool status
| category | name | status | message | path | blocking |
| --- | --- | --- | --- | --- | --- |
| tool | python | OK | executable path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/miniforge3/envs/neoag-core/bin/python | false |
| tool | neoag-v03 | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/project/neo-na0707_upload_release-3/bin/neoag-v03 | false |
| tool | neoag-agent | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/miniforge3/envs/neoag-core/bin/neoag-agent | false |
| tool | neoag-llm-agent | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/project/neo-na0707_upload_release-3/bin/neoag-llm-agent | false |
| tool | arriba | MISSING | not found on PATH | arriba | false |
| tool | ascat | MISSING | not found on PATH | ascat.R | false |
| tool | bigmhc_im | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/project/neo-na0707_upload_release-3/bin/bigmhc_predict | false |
| tool | bwa | MISSING | not found on PATH | bwa | false |
| tool | deepimmuno | MISSING | not found on PATH | deepimmuno-cnn.py | false |
| tool | easyfuse | MISSING | not found on PATH | easyfuse | false |
| tool | facets | MISSING | not found on PATH | runFACETS.R | false |
| tool | fusioncatcher | MISSING | not found on PATH | fusioncatcher | false |
| tool | gatk | MISSING | not found on PATH | gatk | false |
| tool | hla_la | MISSING | not found on PATH | HLA-LA.pl | false |
| tool | java | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/miniforge3/envs/neoag-core/bin/java | false |
| tool | lohhla | MISSING | not found on PATH | LOHHLA | false |
| tool | mhcflurry | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/miniforge3/envs/neoag-tools/bin/mhcflurry-predict | false |
| tool | netmhcpan | LICENSE_REQUIRED | licensed tool; install locally and record path in tools_manifest | netMHCpan | false |
| tool | netmhcstabpan | LICENSE_REQUIRED | licensed tool; install locally and record path in tools_manifest | NetMHCstabpan | false |
| tool | nextflow | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/project/neo-na0707_upload_release-3/bin/nextflow | false |
| tool | optitype | MISSING | not found on PATH | OptiTypePipeline.py | false |
| tool | prime | MISSING | not found on PATH | PRIME | false |
| tool | purple | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/project/neo-na0707_upload_release-3/bin/purple | false |
| tool | pyclone | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/project/neo-na0707_upload_release-3/bin/pyclone | false |
| tool | pyclone_vi | MISSING | not found on PATH | pyclone-vi | false |
| tool | sequenza | MISSING | not found on PATH | sequenza-utils | false |
| tool | spechla | MISSING | not found on PATH | SpecHLA | false |
| tool | star | MISSING | not found on PATH | STAR | false |
| tool | star_fusion | MISSING | not found on PATH | STAR-Fusion | false |
| tool | vep | MISSING | not found on PATH | vep | false |
| entrypoint | neoag-doctor | OK | console script found | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/miniforge3/envs/neoag-core/bin/neoag-doctor | false |
| entrypoint | neoag-release-audit | OK | console script found | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/miniforge3/envs/neoag-core/bin/neoag-release-audit | false |
| entrypoint | neoag-pipeline-full | OK | console script found | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/miniforge3/envs/neoag-core/bin/neoag-pipeline-full | false |
| entrypoint | neoag-gateway | OK | console script found | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/miniforge3/envs/neoag-core/bin/neoag-gateway | false |
| tool_specific | netmhcpan_home | INFO | NETMHCPAN_HOME not set; manifest executable/path may still be sufficient |  | false |
| tool_specific | netmhcpan_env_legacy | INFO | NETMHCpan not set; manifest executable/path may still be sufficient |  | false |
| tool_specific | mhcflurry_data_dir | INFO | MHCFLURRY_DATA_DIR not set; manifest executable/path may still be sufficient |  | false |
| tool_specific | spechla_home | INFO | SPECHLA_HOME not set; manifest executable/path may still be sufficient |  | false |
| tool_specific | hla_la_home | INFO | HLA_LA_HOME not set; manifest executable/path may still be sufficient |  | false |
| tool_specific | purple_home | INFO | PURPLE_HOME not set; manifest executable/path may still be sufficient |  | false |
| tool_specific | vep.mode | INFO | declared install mode: apptainer |  | false |
| tool_specific | netmhcpan.license | LICENSE_REQUIRED | licensed/restricted tool; verify local license and do not redistribute binaries | local_license | false |
| tool_specific | mhcflurry.mode | INFO | declared install mode: conda |  | false |
| tool_specific | lohhla.mode | INFO | declared install mode: container |  | false |
| tool_specific | facets.mode | INFO | declared install mode: conda_or_container |  | false |
| tool_specific | ascat.mode | INFO | declared install mode: conda |  | false |
| tool_specific | arriba.mode | INFO | declared install mode: container |  | false |
| tool_specific | easyfuse.mode | INFO | declared install mode: container |  | false |
| tool_specific | spechla.mode | INFO | declared install mode: conda_or_container |  | false |
| tool_specific | hla_la.mode | INFO | declared install mode: local_or_container |  | false |

## Reference status
| category | name | status | message | path | blocking |
| --- | --- | --- | --- | --- | --- |
| reference | reference_fasta | OK | path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/refs/test_refs/GRCh38.fa | false |
| reference | gencode_gtf | OK | path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/refs/test_refs/gencode.v44.annotation.gtf | false |
| reference | vep_cache | OK | path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/refs/test_refs/vep_cache/homo_sapiens/115_GRCh38 | false |
| reference | protein_fasta | OK | path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/refs/test_refs/protein.fa | false |
| reference | normal_proteome | OK | path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/refs/test_refs/normal_proteome.fa | false |
| reference | normal_ligandome | OK | path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/refs/test_refs/normal_ligandome.tsv | false |
| reference | facets_snp_vcf | OK | path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/refs/test_refs/facets/common_snp.vcf.gz | false |
| sample_input | tumor.wgs_bam | MISSING | path does not exist | data/fixtures/tumor.wgs.bam | false |
| sample_input | tumor.wts_bam | MISSING | path does not exist | data/fixtures/tumor.rna.bam | false |
| sample_input | normal.wgs_bam | MISSING | path does not exist | data/fixtures/normal.wgs.bam | false |
| sample_input | inputs.somatic_vcf | MISSING | path does not exist | data/fixtures/somatic.pass.vcf.gz | false |
| sample_input | inputs.sv_vcf._list[0] | MISSING | path does not exist | data/fixtures/manta.somaticSV.vcf.gz | false |
| sample_input | inputs.fusion_tsv | MISSING | path does not exist | results/SAMPLE001/fusion/fusions.pass.csv | false |
| sample_input | inputs.expression_tsv | MISSING | path does not exist | results/SAMPLE001/rna/gene_tpm.tsv | false |
| sample_input | inputs.purity_tsv | MISSING | path does not exist | results/SAMPLE001/cnv/facets_purity.tsv | false |
| reference_specific | reference_fasta.fai | OK | sidecar exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/refs/test_refs/GRCh38.fa.fai | false |
| reference_specific | reference_fasta.dict | OK | sequence dictionary exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/refs/test_refs/GRCh38.dict | false |
| reference_specific | gencode_gtf | OK | GTF exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/refs/test_refs/gencode.v44.annotation.gtf | false |
| reference_specific | vep_cache_layout | OK | VEP cache path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/refs/test_refs/vep_cache/homo_sapiens/115_GRCh38 | false |
| reference_specific | facets_snp_vcf.tbi | OK | sidecar exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/refs/test_refs/facets/common_snp.vcf.gz.tbi | false |
| reference_specific | lohhla_reference | OK | declared path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/refs/test_refs/lohhla/hla_reference | false |
| reference_specific | ascat_loci | OK | declared path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/refs/test_refs/ascat/G1000_loci_hg38.txt | false |
| reference_specific | ascat_alleles | OK | declared path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/refs/test_refs/ascat/G1000_alleles_hg38.txt | false |
| reference_specific | arriba_reference | OK | declared path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/refs/test_refs/arriba | false |
| reference_specific | hla_reference | OK | declared path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/refs/test_refs/hla | false |

## Smoke tests
| category | name | status | message | path | blocking |
| --- | --- | --- | --- | --- | --- |
| tool_smoke | gatk_mutect2_help | MISSING | gatk not found on PATH | gatk | false |

## All checks
| category | name | status | message | path | blocking |
| --- | --- | --- | --- | --- | --- |
| core | python_import_neoag_v03 | OK | neoag_v03 importable |  | false |
| tool | python | OK | executable path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/miniforge3/envs/neoag-core/bin/python | false |
| tool | neoag-v03 | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/project/neo-na0707_upload_release-3/bin/neoag-v03 | false |
| tool | neoag-agent | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/miniforge3/envs/neoag-core/bin/neoag-agent | false |
| tool | neoag-llm-agent | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/project/neo-na0707_upload_release-3/bin/neoag-llm-agent | false |
| workflow | bin_permissions | OK | bin scripts executable | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/project/neo-na0707_upload_release-3/bin | false |
| workflow | work_write | OK | directory writable | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/project/neo-na0707_upload_release-3/work | false |
| workflow | results_write | OK | directory writable | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/project/neo-na0707_upload_release-3/results | false |
| workflow | profile_local | OK | profile or nextflow.config found | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/project/neo-na0707_upload_release-3/conf/local.config | false |
| workflow | profile_slurm | INFO | profile not found; required only for this execution backend | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/project/neo-na0707_upload_release-3/conf/slurm.config,/mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/project/neo-na0707_upload_release-3/conf/slurm.conf,/mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/project/neo-na0707_upload_release-3/profiles/slurm.config,/mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/project/neo-na0707_upload_release-3/nextflow.config | false |
| workflow | profile_local | OK | profile or nextflow.config found | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/project/neo-na0707_upload_release-3/conf/local.config | false |
| workflow | java_version | DRY_RUN | java -version | java -version | false |
| workflow | nextflow_version | DRY_RUN | nextflow -version | nextflow -version | false |
| tool_smoke | gatk_mutect2_help | MISSING | gatk not found on PATH | gatk | false |
| manifest | tools_manifest | OK | loaded | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/configs/local/tools_manifest.yaml | false |
| manifest | reference_manifest | OK | loaded | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/refs/reference_manifest.test_refs.yaml | false |
| manifest | sample_manifest | OK | loaded | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/configs/local/sample_manifest.yaml | false |
| tool | arriba | MISSING | not found on PATH | arriba | false |
| tool | ascat | MISSING | not found on PATH | ascat.R | false |
| tool | bigmhc_im | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/project/neo-na0707_upload_release-3/bin/bigmhc_predict | false |
| tool | bwa | MISSING | not found on PATH | bwa | false |
| tool | deepimmuno | MISSING | not found on PATH | deepimmuno-cnn.py | false |
| tool | easyfuse | MISSING | not found on PATH | easyfuse | false |
| tool | facets | MISSING | not found on PATH | runFACETS.R | false |
| tool | fusioncatcher | MISSING | not found on PATH | fusioncatcher | false |
| tool | gatk | MISSING | not found on PATH | gatk | false |
| tool | hla_la | MISSING | not found on PATH | HLA-LA.pl | false |
| tool | java | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/miniforge3/envs/neoag-core/bin/java | false |
| tool | lohhla | MISSING | not found on PATH | LOHHLA | false |
| tool | mhcflurry | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/miniforge3/envs/neoag-tools/bin/mhcflurry-predict | false |
| tool | netmhcpan | LICENSE_REQUIRED | licensed tool; install locally and record path in tools_manifest | netMHCpan | false |
| tool | netmhcstabpan | LICENSE_REQUIRED | licensed tool; install locally and record path in tools_manifest | NetMHCstabpan | false |
| tool | nextflow | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/project/neo-na0707_upload_release-3/bin/nextflow | false |
| tool | optitype | MISSING | not found on PATH | OptiTypePipeline.py | false |
| tool | prime | MISSING | not found on PATH | PRIME | false |
| tool | purple | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/project/neo-na0707_upload_release-3/bin/purple | false |
| tool | pyclone | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/project/neo-na0707_upload_release-3/bin/pyclone | false |
| tool | pyclone_vi | MISSING | not found on PATH | pyclone-vi | false |
| tool | sequenza | MISSING | not found on PATH | sequenza-utils | false |
| tool | spechla | MISSING | not found on PATH | SpecHLA | false |
| tool | star | MISSING | not found on PATH | STAR | false |
| tool | star_fusion | MISSING | not found on PATH | STAR-Fusion | false |
| tool | vep | MISSING | not found on PATH | vep | false |
| entrypoint | neoag-doctor | OK | console script found | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/miniforge3/envs/neoag-core/bin/neoag-doctor | false |
| entrypoint | neoag-release-audit | OK | console script found | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/miniforge3/envs/neoag-core/bin/neoag-release-audit | false |
| entrypoint | neoag-pipeline-full | OK | console script found | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/miniforge3/envs/neoag-core/bin/neoag-pipeline-full | false |
| entrypoint | neoag-gateway | OK | console script found | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/miniforge3/envs/neoag-core/bin/neoag-gateway | false |
| tool_specific | netmhcpan_home | INFO | NETMHCPAN_HOME not set; manifest executable/path may still be sufficient |  | false |
| tool_specific | netmhcpan_env_legacy | INFO | NETMHCpan not set; manifest executable/path may still be sufficient |  | false |
| tool_specific | mhcflurry_data_dir | INFO | MHCFLURRY_DATA_DIR not set; manifest executable/path may still be sufficient |  | false |
| tool_specific | spechla_home | INFO | SPECHLA_HOME not set; manifest executable/path may still be sufficient |  | false |
| tool_specific | hla_la_home | INFO | HLA_LA_HOME not set; manifest executable/path may still be sufficient |  | false |
| tool_specific | purple_home | INFO | PURPLE_HOME not set; manifest executable/path may still be sufficient |  | false |
| tool_specific | vep.mode | INFO | declared install mode: apptainer |  | false |
| tool_specific | netmhcpan.license | LICENSE_REQUIRED | licensed/restricted tool; verify local license and do not redistribute binaries | local_license | false |
| tool_specific | mhcflurry.mode | INFO | declared install mode: conda |  | false |
| tool_specific | lohhla.mode | INFO | declared install mode: container |  | false |
| tool_specific | facets.mode | INFO | declared install mode: conda_or_container |  | false |
| tool_specific | ascat.mode | INFO | declared install mode: conda |  | false |
| tool_specific | arriba.mode | INFO | declared install mode: container |  | false |
| tool_specific | easyfuse.mode | INFO | declared install mode: container |  | false |
| tool_specific | spechla.mode | INFO | declared install mode: conda_or_container |  | false |
| tool_specific | hla_la.mode | INFO | declared install mode: local_or_container |  | false |
| reference | reference_fasta | OK | path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/refs/test_refs/GRCh38.fa | false |
| reference | gencode_gtf | OK | path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/refs/test_refs/gencode.v44.annotation.gtf | false |
| reference | vep_cache | OK | path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/refs/test_refs/vep_cache/homo_sapiens/115_GRCh38 | false |
| reference | protein_fasta | OK | path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/refs/test_refs/protein.fa | false |
| reference | normal_proteome | OK | path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/refs/test_refs/normal_proteome.fa | false |
| reference | normal_ligandome | OK | path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/refs/test_refs/normal_ligandome.tsv | false |
| reference | facets_snp_vcf | OK | path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/refs/test_refs/facets/common_snp.vcf.gz | false |
| sample_input | tumor.wgs_bam | MISSING | path does not exist | data/fixtures/tumor.wgs.bam | false |
| sample_input | tumor.wts_bam | MISSING | path does not exist | data/fixtures/tumor.rna.bam | false |
| sample_input | normal.wgs_bam | MISSING | path does not exist | data/fixtures/normal.wgs.bam | false |
| sample_input | inputs.somatic_vcf | MISSING | path does not exist | data/fixtures/somatic.pass.vcf.gz | false |
| sample_input | inputs.sv_vcf._list[0] | MISSING | path does not exist | data/fixtures/manta.somaticSV.vcf.gz | false |
| sample_input | inputs.fusion_tsv | MISSING | path does not exist | results/SAMPLE001/fusion/fusions.pass.csv | false |
| sample_input | inputs.expression_tsv | MISSING | path does not exist | results/SAMPLE001/rna/gene_tpm.tsv | false |
| sample_input | inputs.purity_tsv | MISSING | path does not exist | results/SAMPLE001/cnv/facets_purity.tsv | false |
| reference_specific | reference_fasta.fai | OK | sidecar exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/refs/test_refs/GRCh38.fa.fai | false |
| reference_specific | reference_fasta.dict | OK | sequence dictionary exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/refs/test_refs/GRCh38.dict | false |
| reference_specific | gencode_gtf | OK | GTF exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/refs/test_refs/gencode.v44.annotation.gtf | false |
| reference_specific | vep_cache_layout | OK | VEP cache path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/refs/test_refs/vep_cache/homo_sapiens/115_GRCh38 | false |
| reference_specific | facets_snp_vcf.tbi | OK | sidecar exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/refs/test_refs/facets/common_snp.vcf.gz.tbi | false |
| reference_specific | lohhla_reference | OK | declared path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/refs/test_refs/lohhla/hla_reference | false |
| reference_specific | ascat_loci | OK | declared path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/refs/test_refs/ascat/G1000_loci_hg38.txt | false |
| reference_specific | ascat_alleles | OK | declared path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/refs/test_refs/ascat/G1000_alleles_hg38.txt | false |
| reference_specific | arriba_reference | OK | declared path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/refs/test_refs/arriba | false |
| reference_specific | hla_reference | OK | declared path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/new_machine_bundle_selftest/neoag_migration_bundle/refs/test_refs/hla | false |
