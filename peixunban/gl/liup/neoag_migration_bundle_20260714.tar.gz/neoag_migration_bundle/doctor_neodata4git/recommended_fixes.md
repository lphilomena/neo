# Recommended fixes

## arriba [MISSING]

- Message: not found on PATH
- Path: arriba
- Suggested fix: Install the tool or set its executable path in tools_manifest.

## deepimmuno [MISSING]

- Message: not found on PATH
- Path: DeepImmuno
- Suggested fix: Install the tool or set its executable path in tools_manifest.

## easyfuse [MISSING]

- Message: not found on PATH
- Path: easyfuse
- Suggested fix: Install the tool or set its executable path in tools_manifest.

## fusioncatcher [MISSING]

- Message: not found on PATH
- Path: fusioncatcher
- Suggested fix: Install the tool or set its executable path in tools_manifest.

## hla_la [MISSING]

- Message: not found on PATH
- Path: HLA-LA.pl
- Suggested fix: Install the tool or set its executable path in tools_manifest.

## lohhla [MISSING]

- Message: not found on PATH
- Path: LOHHLA
- Suggested fix: Install the tool or set its executable path in tools_manifest.

## optitype [MISSING]

- Message: not found on PATH
- Path: OptiTypePipeline.py
- Suggested fix: Install the tool or set its executable path in tools_manifest.

## sequenza [MISSING]

- Message: not found on PATH
- Path: sequenza-utils
- Suggested fix: Install the tool or set its executable path in tools_manifest.

## spechla [MISSING]

- Message: not found on PATH
- Path: SpecHLA
- Suggested fix: Install the tool or set its executable path in tools_manifest.

## star [MISSING]

- Message: not found on PATH
- Path: STAR
- Suggested fix: Install the tool or set its executable path in tools_manifest.

## star_fusion [MISSING]

- Message: not found on PATH
- Path: STAR-Fusion
- Suggested fix: Install the tool or set its executable path in tools_manifest.

## netmhcpan.license [LICENSE_REQUIRED]

- Message: licensed/restricted tool; verify local license and do not redistribute binaries
- Path: local_license
- Suggested fix: Install/configure this licensed tool locally; do not redistribute binaries or licensed data.

## tumor.wgs_bam [MISSING]

- Message: path does not exist
- Path: data/fixtures/tumor.wgs.bam
- Suggested fix: Review the manifest entry and installation path.

## tumor.wts_bam [MISSING]

- Message: path does not exist
- Path: data/fixtures/tumor.rna.bam
- Suggested fix: Review the manifest entry and installation path.

## normal.wgs_bam [MISSING]

- Message: path does not exist
- Path: data/fixtures/normal.wgs.bam
- Suggested fix: Review the manifest entry and installation path.

## inputs.somatic_vcf [MISSING]

- Message: path does not exist
- Path: data/fixtures/somatic.pass.vcf.gz
- Suggested fix: Review the manifest entry and installation path.

## inputs.sv_vcf._list[0] [MISSING]

- Message: path does not exist
- Path: data/fixtures/manta.somaticSV.vcf.gz
- Suggested fix: Review the manifest entry and installation path.

## inputs.fusion_tsv [MISSING]

- Message: path does not exist
- Path: results/SAMPLE001/fusion/fusions.pass.csv
- Suggested fix: Review the manifest entry and installation path.

## inputs.expression_tsv [MISSING]

- Message: path does not exist
- Path: results/SAMPLE001/rna/gene_tpm.tsv
- Suggested fix: Review the manifest entry and installation path.

## inputs.purity_tsv [MISSING]

- Message: path does not exist
- Path: results/SAMPLE001/cnv/facets_purity.tsv
- Suggested fix: Review the manifest entry and installation path.

## vep_cache_layout [WARN]

- Message: VEP cache exists but species/build layout was not recognized
- Path: /mnt/zjl-bgi-zzb/peixunban/gl/liup/neodata4git/data/vep
- Suggested fix: Download or symlink the required reference file/cache and update reference_manifest.

