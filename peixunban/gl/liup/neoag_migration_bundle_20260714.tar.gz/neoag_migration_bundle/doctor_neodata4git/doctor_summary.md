# NeoAg Doctor

Status: **PARTIAL**
Checked at: 2026-07-14T18:24:52+0800

## Summary
| OK | INFO | DRY_RUN | MISSING | LICENSE_REQUIRED | WARN |
| --- | --- | --- | --- | --- | --- |
| 53 | 14 | 3 | 19 | 1 | 1 |

## Blocking issues

（无记录）


## Tool status
| category | name | status | message | path | blocking |
| --- | --- | --- | --- | --- | --- |
| tool | python | OK | executable path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/miniforge3/envs/neoag-core/bin/python | false |
| tool | neoag-v03 | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neoag_migration_bundle/project/neo-na0707_upload_release-3/bin/neoag-v03 | false |
| tool | neoag-agent | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/miniforge3/envs/neoag-core/bin/neoag-agent | false |
| tool | neoag-llm-agent | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neoag_migration_bundle/project/neo-na0707_upload_release-3/bin/neoag-llm-agent | false |
| tool | arriba | MISSING | not found on PATH | arriba | false |
| tool | ascat | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/miniforge3/envs/neoag-facets/bin/Rscript | false |
| tool | bigmhc | OK | executable path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neodata4git/data/predictors/bigmhc | false |
| tool | bigmhc_im | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neoag_migration_bundle/project/neo-na0707_upload_release-3/bin/bigmhc_predict | false |
| tool | bwa | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/miniforge3/envs/neoag-gatk/bin/bwa | false |
| tool | deepimmuno | MISSING | not found on PATH | DeepImmuno | false |
| tool | easyfuse | MISSING | not found on PATH | easyfuse | false |
| tool | facets | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/miniforge3/envs/neoag-facets/bin/Rscript | false |
| tool | fusioncatcher | MISSING | not found on PATH | fusioncatcher | false |
| tool | gatk | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/miniforge3/envs/neoag-gatk/bin/gatk | false |
| tool | hla_la | MISSING | not found on PATH | HLA-LA.pl | false |
| tool | java | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/miniforge3/envs/neoag-core/bin/java | false |
| tool | lohhla | MISSING | not found on PATH | LOHHLA | false |
| tool | mhcflurry | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/miniforge3/envs/neoag-tools/bin/mhcflurry-predict | false |
| tool | mixmhcpred | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/wrappers/mixMHCpred_install/MixMHCpred | false |
| tool | netmhcpan | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/bin/netMHCpan | false |
| tool | netmhcstabpan | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/bin/NetMHCstabpan | false |
| tool | nextflow | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neoag_migration_bundle/project/neo-na0707_upload_release-3/bin/nextflow | false |
| tool | optitype | MISSING | not found on PATH | OptiTypePipeline.py | false |
| tool | prime | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/tools/prime/PRIME | false |
| tool | purple | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neoag_migration_bundle/project/neo-na0707_upload_release-3/bin/purple | false |
| tool | pyclone | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neoag_migration_bundle/project/neo-na0707_upload_release-3/bin/pyclone | false |
| tool | pyclone_vi | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/miniforge3/envs/neoag-pyclone/bin/pyclone-vi | false |
| tool | sequenza | MISSING | not found on PATH | sequenza-utils | false |
| tool | spechla | MISSING | not found on PATH | SpecHLA | false |
| tool | star | MISSING | not found on PATH | STAR | false |
| tool | star_fusion | MISSING | not found on PATH | STAR-Fusion | false |
| tool | vep | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/miniforge3/envs/neoag-vep/bin/vep | false |
| entrypoint | neoag-doctor | OK | console script found | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/miniforge3/envs/neoag-core/bin/neoag-doctor | false |
| entrypoint | neoag-release-audit | OK | console script found | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/miniforge3/envs/neoag-core/bin/neoag-release-audit | false |
| entrypoint | neoag-pipeline-full | OK | console script found | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/miniforge3/envs/neoag-core/bin/neoag-pipeline-full | false |
| entrypoint | neoag-gateway | OK | console script found | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/miniforge3/envs/neoag-core/bin/neoag-gateway | false |
| tool_specific | netmhcpan_home | OK | NETMHCPAN_HOME set | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neodata4git/data/predictors/netMHCpan | false |
| tool_specific | netmhcpan_env_legacy | OK | NETMHCpan set | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neodata4git/data/predictors/netMHCpan | false |
| tool_specific | mhcflurry_data_dir | INFO | MHCFLURRY_DATA_DIR not set; manifest executable/path may still be sufficient |  | false |
| tool_specific | spechla_home | INFO | SPECHLA_HOME not set; manifest executable/path may still be sufficient |  | false |
| tool_specific | hla_la_home | INFO | HLA_LA_HOME not set; manifest executable/path may still be sufficient |  | false |
| tool_specific | purple_home | INFO | PURPLE_HOME not set; manifest executable/path may still be sufficient |  | false |
| tool_specific | vep.mode | INFO | declared install mode: conda |  | false |
| tool_specific | netmhcpan.license | LICENSE_REQUIRED | licensed/restricted tool; verify local license and do not redistribute binaries | local_license | false |
| tool_specific | mhcflurry.mode | INFO | declared install mode: conda |  | false |
| tool_specific | lohhla.mode | INFO | declared install mode: local_or_container |  | false |
| tool_specific | facets.mode | INFO | declared install mode: conda |  | false |
| tool_specific | ascat.mode | INFO | declared install mode: conda |  | false |
| tool_specific | arriba.mode | INFO | declared install mode: container_tar |  | false |
| tool_specific | easyfuse.mode | INFO | declared install mode: container_tar |  | false |
| tool_specific | spechla.mode | INFO | declared install mode: container_tar |  | false |
| tool_specific | hla_la.mode | INFO | declared install mode: container_tar |  | false |

## Reference status
| category | name | status | message | path | blocking |
| --- | --- | --- | --- | --- | --- |
| reference | reference_fasta | OK | path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neodata4git/data/ref/hg38/Homo_sapiens_assembly38.fasta | false |
| reference | gencode_gtf | OK | path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neodata4git/data/ref/hg38/gencode.gtf | false |
| reference | vep_cache | OK | path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neodata4git/data/vep | false |
| reference | protein_fasta | OK | path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neodata4git/data/normal/proteome/Homo_sapiens.GRCh38.pep.all.fa | false |
| reference | normal_proteome | OK | path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neodata4git/data/normal/proteome/Homo_sapiens.GRCh38.pep.all.fa | false |
| reference | normal_ligandome | OK | path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/refs/normal/normal_hla_ligands.hla_ligand_atlas.predicted_alleles.tsv | false |
| reference | facets_snp_vcf | OK | path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neodata4git/data/facets/reference/common_snp.hg38.vcf.gz | false |
| reference | sequenza_reference_fasta | OK | path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neodata4git/data/sequenza/reference/GRCh38.primary_assembly.chr.fa | false |
| sample_input | tumor.wgs_bam | MISSING | path does not exist | data/fixtures/tumor.wgs.bam | false |
| sample_input | tumor.wts_bam | MISSING | path does not exist | data/fixtures/tumor.rna.bam | false |
| sample_input | normal.wgs_bam | MISSING | path does not exist | data/fixtures/normal.wgs.bam | false |
| sample_input | inputs.somatic_vcf | MISSING | path does not exist | data/fixtures/somatic.pass.vcf.gz | false |
| sample_input | inputs.sv_vcf[0] | MISSING | path does not exist | data/fixtures/manta.somaticSV.vcf.gz | false |
| sample_input | inputs.fusion_tsv | MISSING | path does not exist | results/SAMPLE001/fusion/fusions.pass.csv | false |
| sample_input | inputs.expression_tsv | MISSING | path does not exist | results/SAMPLE001/rna/gene_tpm.tsv | false |
| sample_input | inputs.purity_tsv | MISSING | path does not exist | results/SAMPLE001/cnv/facets_purity.tsv | false |
| reference_specific | reference_fasta.fai | OK | sidecar exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neodata4git/data/ref/hg38/Homo_sapiens_assembly38.fasta.fai | false |
| reference_specific | reference_fasta.dict | OK | sequence dictionary exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neodata4git/data/ref/hg38/Homo_sapiens_assembly38.dict | false |
| reference_specific | gencode_gtf | OK | GTF exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neodata4git/data/ref/hg38/gencode.gtf | false |
| reference_specific | vep_cache_layout | WARN | VEP cache exists but species/build layout was not recognized | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neodata4git/data/vep | false |
| reference_specific | facets_snp_vcf.tbi | OK | sidecar exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neodata4git/data/facets/reference/common_snp.hg38.vcf.gz.tbi | false |
| reference_specific | lohhla_reference | OK | declared path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neodata4git/data/lohhla/polysolver | false |
| reference_specific | ascat_loci | OK | declared path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neodata4git/data/ascat/reference/WGS_hg38/smoke_chr1_100_nochr_name/loci/G1000_loci_hg38_1.txt | false |
| reference_specific | ascat_alleles | OK | declared path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neodata4git/data/ascat/reference/WGS_hg38/smoke_chr1_100_nochr_name/alleles/G1000_alleles_hg38_1.txt | false |
| reference_specific | arriba_reference | OK | declared path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/refs/arriba | false |
| reference_specific | hla_reference | OK | declared path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neodata4git/data/hla/spechla_db | false |

## Smoke tests
| category | name | status | message | path | blocking |
| --- | --- | --- | --- | --- | --- |
| tool_smoke | gatk_mutect2_help | DRY_RUN | gatk Mutect2 --help | gatk Mutect2 --help | false |

## All checks
| category | name | status | message | path | blocking |
| --- | --- | --- | --- | --- | --- |
| core | python_import_neoag_v03 | OK | neoag_v03 importable |  | false |
| tool | python | OK | executable path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/miniforge3/envs/neoag-core/bin/python | false |
| tool | neoag-v03 | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neoag_migration_bundle/project/neo-na0707_upload_release-3/bin/neoag-v03 | false |
| tool | neoag-agent | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/miniforge3/envs/neoag-core/bin/neoag-agent | false |
| tool | neoag-llm-agent | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neoag_migration_bundle/project/neo-na0707_upload_release-3/bin/neoag-llm-agent | false |
| workflow | bin_permissions | OK | bin scripts executable | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neoag_migration_bundle/project/neo-na0707_upload_release-3/bin | false |
| workflow | work_write | OK | directory writable | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neoag_migration_bundle/project/neo-na0707_upload_release-3/work | false |
| workflow | results_write | OK | directory writable | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neoag_migration_bundle/project/neo-na0707_upload_release-3/results | false |
| workflow | profile_local | OK | profile or nextflow.config found | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neoag_migration_bundle/project/neo-na0707_upload_release-3/conf/local.config | false |
| workflow | profile_slurm | INFO | profile not found; required only for this execution backend | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neoag_migration_bundle/project/neo-na0707_upload_release-3/conf/slurm.config,/mnt/zjl-bgi-zzb/peixunban/gl/liup/neoag_migration_bundle/project/neo-na0707_upload_release-3/conf/slurm.conf,/mnt/zjl-bgi-zzb/peixunban/gl/liup/neoag_migration_bundle/project/neo-na0707_upload_release-3/profiles/slurm.config,/mnt/zjl-bgi-zzb/peixunban/gl/liup/neoag_migration_bundle/project/neo-na0707_upload_release-3/nextflow.config | false |
| workflow | profile_local | OK | profile or nextflow.config found | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neoag_migration_bundle/project/neo-na0707_upload_release-3/conf/local.config | false |
| workflow | java_version | DRY_RUN | java -version | java -version | false |
| workflow | nextflow_version | DRY_RUN | nextflow -version | nextflow -version | false |
| tool_smoke | gatk_mutect2_help | DRY_RUN | gatk Mutect2 --help | gatk Mutect2 --help | false |
| manifest | tools_manifest | OK | loaded | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neoag_migration_bundle/configs/local/tools_manifest.neodata4git.yaml | false |
| manifest | reference_manifest | OK | loaded | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neoag_migration_bundle/refs/reference_manifest.neodata4git.yaml | false |
| manifest | sample_manifest | OK | loaded | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neoag_migration_bundle/configs/local/sample_manifest.yaml | false |
| tool | arriba | MISSING | not found on PATH | arriba | false |
| tool | ascat | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/miniforge3/envs/neoag-facets/bin/Rscript | false |
| tool | bigmhc | OK | executable path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neodata4git/data/predictors/bigmhc | false |
| tool | bigmhc_im | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neoag_migration_bundle/project/neo-na0707_upload_release-3/bin/bigmhc_predict | false |
| tool | bwa | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/miniforge3/envs/neoag-gatk/bin/bwa | false |
| tool | deepimmuno | MISSING | not found on PATH | DeepImmuno | false |
| tool | easyfuse | MISSING | not found on PATH | easyfuse | false |
| tool | facets | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/miniforge3/envs/neoag-facets/bin/Rscript | false |
| tool | fusioncatcher | MISSING | not found on PATH | fusioncatcher | false |
| tool | gatk | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/miniforge3/envs/neoag-gatk/bin/gatk | false |
| tool | hla_la | MISSING | not found on PATH | HLA-LA.pl | false |
| tool | java | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/miniforge3/envs/neoag-core/bin/java | false |
| tool | lohhla | MISSING | not found on PATH | LOHHLA | false |
| tool | mhcflurry | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/miniforge3/envs/neoag-tools/bin/mhcflurry-predict | false |
| tool | mixmhcpred | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/wrappers/mixMHCpred_install/MixMHCpred | false |
| tool | netmhcpan | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/bin/netMHCpan | false |
| tool | netmhcstabpan | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/bin/NetMHCstabpan | false |
| tool | nextflow | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neoag_migration_bundle/project/neo-na0707_upload_release-3/bin/nextflow | false |
| tool | optitype | MISSING | not found on PATH | OptiTypePipeline.py | false |
| tool | prime | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/tools/prime/PRIME | false |
| tool | purple | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neoag_migration_bundle/project/neo-na0707_upload_release-3/bin/purple | false |
| tool | pyclone | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neoag_migration_bundle/project/neo-na0707_upload_release-3/bin/pyclone | false |
| tool | pyclone_vi | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/miniforge3/envs/neoag-pyclone/bin/pyclone-vi | false |
| tool | sequenza | MISSING | not found on PATH | sequenza-utils | false |
| tool | spechla | MISSING | not found on PATH | SpecHLA | false |
| tool | star | MISSING | not found on PATH | STAR | false |
| tool | star_fusion | MISSING | not found on PATH | STAR-Fusion | false |
| tool | vep | OK | found on PATH | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/miniforge3/envs/neoag-vep/bin/vep | false |
| entrypoint | neoag-doctor | OK | console script found | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/miniforge3/envs/neoag-core/bin/neoag-doctor | false |
| entrypoint | neoag-release-audit | OK | console script found | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/miniforge3/envs/neoag-core/bin/neoag-release-audit | false |
| entrypoint | neoag-pipeline-full | OK | console script found | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/miniforge3/envs/neoag-core/bin/neoag-pipeline-full | false |
| entrypoint | neoag-gateway | OK | console script found | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/miniforge3/envs/neoag-core/bin/neoag-gateway | false |
| tool_specific | netmhcpan_home | OK | NETMHCPAN_HOME set | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neodata4git/data/predictors/netMHCpan | false |
| tool_specific | netmhcpan_env_legacy | OK | NETMHCpan set | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neodata4git/data/predictors/netMHCpan | false |
| tool_specific | mhcflurry_data_dir | INFO | MHCFLURRY_DATA_DIR not set; manifest executable/path may still be sufficient |  | false |
| tool_specific | spechla_home | INFO | SPECHLA_HOME not set; manifest executable/path may still be sufficient |  | false |
| tool_specific | hla_la_home | INFO | HLA_LA_HOME not set; manifest executable/path may still be sufficient |  | false |
| tool_specific | purple_home | INFO | PURPLE_HOME not set; manifest executable/path may still be sufficient |  | false |
| tool_specific | vep.mode | INFO | declared install mode: conda |  | false |
| tool_specific | netmhcpan.license | LICENSE_REQUIRED | licensed/restricted tool; verify local license and do not redistribute binaries | local_license | false |
| tool_specific | mhcflurry.mode | INFO | declared install mode: conda |  | false |
| tool_specific | lohhla.mode | INFO | declared install mode: local_or_container |  | false |
| tool_specific | facets.mode | INFO | declared install mode: conda |  | false |
| tool_specific | ascat.mode | INFO | declared install mode: conda |  | false |
| tool_specific | arriba.mode | INFO | declared install mode: container_tar |  | false |
| tool_specific | easyfuse.mode | INFO | declared install mode: container_tar |  | false |
| tool_specific | spechla.mode | INFO | declared install mode: container_tar |  | false |
| tool_specific | hla_la.mode | INFO | declared install mode: container_tar |  | false |
| reference | reference_fasta | OK | path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neodata4git/data/ref/hg38/Homo_sapiens_assembly38.fasta | false |
| reference | gencode_gtf | OK | path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neodata4git/data/ref/hg38/gencode.gtf | false |
| reference | vep_cache | OK | path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neodata4git/data/vep | false |
| reference | protein_fasta | OK | path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neodata4git/data/normal/proteome/Homo_sapiens.GRCh38.pep.all.fa | false |
| reference | normal_proteome | OK | path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neodata4git/data/normal/proteome/Homo_sapiens.GRCh38.pep.all.fa | false |
| reference | normal_ligandome | OK | path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/refs/normal/normal_hla_ligands.hla_ligand_atlas.predicted_alleles.tsv | false |
| reference | facets_snp_vcf | OK | path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neodata4git/data/facets/reference/common_snp.hg38.vcf.gz | false |
| reference | sequenza_reference_fasta | OK | path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neodata4git/data/sequenza/reference/GRCh38.primary_assembly.chr.fa | false |
| sample_input | tumor.wgs_bam | MISSING | path does not exist | data/fixtures/tumor.wgs.bam | false |
| sample_input | tumor.wts_bam | MISSING | path does not exist | data/fixtures/tumor.rna.bam | false |
| sample_input | normal.wgs_bam | MISSING | path does not exist | data/fixtures/normal.wgs.bam | false |
| sample_input | inputs.somatic_vcf | MISSING | path does not exist | data/fixtures/somatic.pass.vcf.gz | false |
| sample_input | inputs.sv_vcf[0] | MISSING | path does not exist | data/fixtures/manta.somaticSV.vcf.gz | false |
| sample_input | inputs.fusion_tsv | MISSING | path does not exist | results/SAMPLE001/fusion/fusions.pass.csv | false |
| sample_input | inputs.expression_tsv | MISSING | path does not exist | results/SAMPLE001/rna/gene_tpm.tsv | false |
| sample_input | inputs.purity_tsv | MISSING | path does not exist | results/SAMPLE001/cnv/facets_purity.tsv | false |
| reference_specific | reference_fasta.fai | OK | sidecar exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neodata4git/data/ref/hg38/Homo_sapiens_assembly38.fasta.fai | false |
| reference_specific | reference_fasta.dict | OK | sequence dictionary exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neodata4git/data/ref/hg38/Homo_sapiens_assembly38.dict | false |
| reference_specific | gencode_gtf | OK | GTF exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neodata4git/data/ref/hg38/gencode.gtf | false |
| reference_specific | vep_cache_layout | WARN | VEP cache exists but species/build layout was not recognized | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neodata4git/data/vep | false |
| reference_specific | facets_snp_vcf.tbi | OK | sidecar exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neodata4git/data/facets/reference/common_snp.hg38.vcf.gz.tbi | false |
| reference_specific | lohhla_reference | OK | declared path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neodata4git/data/lohhla/polysolver | false |
| reference_specific | ascat_loci | OK | declared path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neodata4git/data/ascat/reference/WGS_hg38/smoke_chr1_100_nochr_name/loci/G1000_loci_hg38_1.txt | false |
| reference_specific | ascat_alleles | OK | declared path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neodata4git/data/ascat/reference/WGS_hg38/smoke_chr1_100_nochr_name/alleles/G1000_alleles_hg38_1.txt | false |
| reference_specific | arriba_reference | OK | declared path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/test_env_tools/refs/arriba | false |
| reference_specific | hla_reference | OK | declared path exists | /mnt/zjl-bgi-zzb/peixunban/gl/liup/neodata4git/data/hla/spechla_db | false |
